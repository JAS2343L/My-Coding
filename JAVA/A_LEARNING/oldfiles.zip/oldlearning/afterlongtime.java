package A_LEARNING.oldlearning;

import java.util.Scanner;
import java.util.ArrayList;


public class afterlongtime {
    Scanner ask = new Scanner(System.in);
    ArrayList<String> list = new ArrayList<>();

    afterlongtime(){
        System.out.print("\033c");
        practice();
    }
    
    public void practice(){
        while(true){
            System.out.print("Type Anything or \"exit\": ");
            String words = ask.nextLine();
    
            if(words.equalsIgnoreCase("exit")){
                System.out.print("\033c");
                for (String prrnt : list){
                    System.out.println(prrnt);
                }
                break;
            }else{
                list.add(words);
            }
        }
    }

    public static void main(String[] args) {
        new afterlongtime();
    }
}
