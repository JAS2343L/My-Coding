package A_LEARNING;

import java.util.Scanner;

public class BankApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        BankAccount account = new BankAccount("Rajat", 1000);

        while (true) {
            System.out.println("\n=== Bank Menu ===");
            System.out.println("1. Show balance");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Exit");
            System.out.print("Choose option: ");

            int option = scanner.nextInt();
            scanner.nextLine(); // consume newline

            if (option == 1) {
                account.printBalance();
            } else if (option == 2) {
                System.out.print("Amount to deposit: ");
                double amount = scanner.nextDouble();
                scanner.nextLine();
                account.deposit(amount);
            } else if (option == 3) {
                System.out.print("Amount to withdraw: ");
                double amount = scanner.nextDouble();
                scanner.nextLine();
                account.withdraw(amount);
            } else if (option == 4) {
                System.out.println("Goodbye!");
                break;
            } else {
                System.out.println("Invalid option, try again.");
            }
        }

        scanner.close();
    }
}

class BankAccount {
    private String owner;
    private double balance;

    public BankAccount(String owner, double startingBalance) {
        this.owner = owner;
        this.balance = startingBalance;
    }

    public void deposit(double amount) {
        if (amount <= 0) {
            System.out.println("Deposit amount must be positive.");
            return;
        }
        balance += amount;
        System.out.println("Deposited " + amount + " successfully.");
        printBalance();
    }

    public void withdraw(double amount) {
        if (amount <= 0) {
            System.out.println("Withdrawal amount must be positive.");
            return;
        }
        if (amount > balance) {
            System.out.println("Not enough balance. Current balance: " + balance);
            return;
        }
        balance -= amount;
        System.out.println("Withdrew " + amount + " successfully.");
        printBalance();
    }

    public void printBalance() {
        System.out.println(owner + "'s balance: " + balance);
    }
}
