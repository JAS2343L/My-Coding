package A_LEARNING.Class;

class redprint {
    private int a = 100;

    public void changea(String neew){
        if(neew.isEmpty()){
            System.out.print(a);
        }else{
            int x = Integer.parseInt(neew);
            a = x;
            System.out.print(a);
        }
    }
    }