package A_LEARNING.Class;
import java.util.Scanner;

public class classpractice {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        redprint abcd = new redprint();
        System.out.print("\033ctype number:");
        String o = s.nextLine();
        abcd.changea(o);
    }
}
