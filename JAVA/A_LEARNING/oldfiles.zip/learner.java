package A_LEARNING;

public class learner {
    public static void main(String[] args) {
        
    }
}