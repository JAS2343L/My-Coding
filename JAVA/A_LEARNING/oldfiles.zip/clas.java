package A_LEARNING;

class redprint {
    private String name;
    private int age;

    public redprint(String name, int age) {
        this.name = name;
        this.age = age;
        System.out.println(name + age);
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }
}